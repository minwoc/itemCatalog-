ABOUT:
This project scopes into fundamentals of database backend concepts. Goal is to learn to develop
RESTful web application using Python framework Flask and building third party OAuth authentication.
When user is logged in, too, they should be able to update, delete, or edit selected item.
This project will build knowledge of creating website with data storage to make web application to
the users.

Tools:
python
vagrant
virtual box
Terminal
Google email

Set Up:
Install vagrant and virtual machine on your computer.

Run Outputs:
1. Change directory into vagrant directory.
2. Open up command line.
3. Run vagrant up.
4. Run vagrant provision.
5. Run vagrant ssh.
6. Then cd /vagrant/d.
7. Run python project.py.
8. Finally, open up your browser and type in http://localhost:5000/
